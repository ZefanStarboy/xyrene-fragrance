# XYRENE FRAGRANCE

Website parfum dark-mode yang menampilkan katalog produk, fitur troli, checkout, verifikasi admin, dan login user.

### 📦 Fitur
- Login user + verifikasi email (Supabase)
- Dashboard admin (multi-email whitelist)
- Tambah & edit produk langsung via dashboard
- Diskon, preorder, stok habis otomatis nonaktif
- Troli persistent per user
- Upload bukti pembayaran
- Admin verifikasi pesanan dari dashboard
- Riwayat pembelian user
- Mode gelap default

### 🚀 Deploy
1. Clone repo
2. Jalankan `npm install`
3. Jalankan `npm run dev`
4. Untuk build production: `npm run build`

Made for Netlify deployment.